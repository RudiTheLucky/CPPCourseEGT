#pragma once
#include "defines.h"
class Segment {
public:
	Segment(Drawable, int, int);
	~Segment();
	Drawable getDrawable();
	int m_angle;
	int m_points;
private:
	Drawable m_drawable;
	SDL_Texture* m_drawableText;
};